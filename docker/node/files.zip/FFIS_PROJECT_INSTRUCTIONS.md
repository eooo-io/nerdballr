# Football Field Intelligence System
## Project Instructions v2.0

---

## Role

You are assisting in the design and implementation of the **Football Field Intelligence System (FFIS)** — an interactive tactical visualization simulator for understanding American football formations, strategy, and spatial geometry.

This is not a game. It is not a sports analytics platform.
It is a **teaching and exploration tool** that allows users to visually study how football tactics work.

The simulator should feel like a retro-inspired tactical workstation — polished, purposeful, and educational.

---

## Core Purpose

FFIS allows users to visually explore:

- Offensive and defensive formations
- Coverage shells (Cover 0 through Cover 6)
- Blitz patterns and pressure packages
- Route concepts (individual routes and combination concepts)
- Pocket mechanics
- Ball trajectory physics (line-drive, rainbow, screen, scramble)
- Defender reaction geometry
- Quarterback decision timing and pre-snap reads

The simulator must help users understand **why plays work** — not merely display diagrams.

---

## Visual Philosophy

### Retro inspiration
- Amiga / early workstation aesthetic
- Disciplined, minimal color palette
- Symbolic player tokens (no silhouettes or photographic elements)
- Structured grid layouts with visible field lines

### Modern rendering
- Smooth Framer Motion animation
- Bezier curved path rendering
- Scalable SVG graphics
- Responsive layout

The interface must feel like a **coach's tactical workstation**, not a sports video game.

---

## Technology Stack

### Frontend — Standalone SPA

| Layer | Choice | Rationale |
|---|---|---|
| Framework | React 18 + TypeScript | Best component model for complex stateful UIs |
| Build tool | Vite | Fastest HMR — essential for tight animation iteration |
| Rendering | SVG (native React) | Vector, scalable, animatable, export-ready |
| Animation | Framer Motion | Best-in-class SVG animation for React |
| State | Zustand | Lightweight slices, no boilerplate |
| Routing | React Router v6 | Mode navigation (Lesson / Compare / Lab) |
| Styling | TailwindCSS + CSS variables | Retro palette via variables, utilities for layout |
| Icons | Lucide React | Consistent, clean icon set |

The frontend is a standalone SPA. It communicates with the Laravel backend **exclusively via REST API**. It has no knowledge of the backend framework.

### Backend — Laravel 11 API

| Layer | Choice |
|---|---|
| Framework | Laravel 11 |
| Auth | Laravel Sanctum (SPA token auth) |
| Database | MariaDB 11 |
| Cache | Redis 7 |
| Queue | Laravel Horizon |
| Storage | MinIO (S3-compatible) |

### AI Layer

| Layer | Choice |
|---|---|
| Model | Claude via Anthropic API |
| Pattern | RAG — concept data retrieved from MariaDB, injected as context |
| Proxy | Laravel controller (API key never exposed to client) |

---

## Repository Structure

```
ffis/
├── docker-compose.yml          # Dev environment (all services)
├── docker/
│   ├── nginx/default.conf      # Reverse proxy routing
│   ├── php/Dockerfile          # PHP 8.3 / Laravel image
│   ├── php/php.ini             # PHP dev config
│   ├── node/Dockerfile         # Node 20 / Vite image
│   └── mariadb/init.sql        # DB charset init
├── Makefile                    # Developer convenience commands
├── .env                        # Root secrets (never commit)
├── .env.example                # Safe template (commit this)
├── .gitignore
│
├── backend/                    # Laravel 11 application
│   ├── app/
│   │   ├── Http/Controllers/
│   │   │   ├── ConceptController.php
│   │   │   ├── AiController.php
│   │   │   ├── BookmarkController.php
│   │   │   └── ProgressController.php
│   │   ├── Models/
│   │   │   ├── Concept.php
│   │   │   ├── User.php
│   │   │   ├── UserBookmark.php
│   │   │   ├── UserProgress.php
│   │   │   ├── CustomPlay.php
│   │   │   └── AiSession.php
│   │   └── Services/
│   │       └── AiService.php   # Anthropic API proxy + intent parsing
│   ├── database/
│   │   ├── migrations/
│   │   └── seeders/
│   │       └── ConceptSeeder.php
│   └── routes/api.php
│
└── frontend/                   # React 18 + Vite SPA
    ├── src/
    │   ├── components/
    │   │   ├── canvas/         # SVG field rendering
    │   │   ├── controls/       # Playback, timeline, scrubber
    │   │   ├── sidebar/        # Concept library, search
    │   │   └── panels/         # Explanation, legend, overlays
    │   ├── stores/             # Zustand state slices
    │   │   ├── lessonStore.ts
    │   │   ├── compareStore.ts
    │   │   └── userStore.ts
    │   ├── types/              # TypeScript interfaces (canonical)
    │   │   └── index.ts
    │   └── routes/             # React Router pages
    │       ├── LessonPage.tsx
    │       ├── ComparePage.tsx
    │       └── GeometryLabPage.tsx
    └── vite.config.ts
```

---

## Dev Environment

### Services (Docker Compose)

| Service | Purpose | URL |
|---|---|---|
| nginx | Reverse proxy — routes API and SPA | http://localhost |
| frontend | Vite dev server with HMR | http://localhost:5173 |
| backend | Laravel (php-fpm) | Internal only |
| mariadb | MariaDB 11 | localhost:3306 |
| redis | Cache + queue | localhost:6379 |
| minio | Object storage | http://localhost:9000 |
| minio (console) | MinIO web UI | http://localhost:9001 |
| horizon | Laravel queue worker | Internal only |
| mailpit | Local mail catcher | http://localhost:8025 |

### Starting the environment

```bash
# First time
cp .env.example .env        # Fill in secrets
make build                  # Build images
make up                     # Start all services
make install                # Composer install + migrate + seed

# Daily
make up
make logs
```

### Common commands

```bash
make migrate          # Run new migrations
make fresh            # Drop and rebuild database (destructive)
make tinker           # Laravel Tinker REPL
make shell-backend    # Shell into the Laravel container
make shell-frontend   # Shell into the Node container
make horizon-status   # Check queue worker
make help             # Full command reference
```

### Nginx routing

| Pattern | Destination |
|---|---|
| `/api/*` | Laravel php-fpm |
| `/sanctum/*` | Laravel (CSRF) |
| `/__vite_hmr` | Vite WebSocket |
| `/*` (everything else) | Vite dev server |

---

## Data Model

### Field Coordinate System

The field is represented as a 2D logical grid:

```
X: 0 – 1200   (1 unit = 0.1 yards → full field: 120 yards)
Y: 0 – 533    (1 unit = 0.1 yards → field width: 53.3 yards)
```

All player positions, paths, and overlays use this coordinate space. SVG rendering maps logical units directly to viewport units via a viewBox transform. This gives sub-yard precision for smooth curves without floating-point issues.

### Player Token System

Each player role maps to a consistent visual token that never changes across concepts:

| Role | Shape | Color |
|---|---|---|
| QB | Circle | Blue `#3B82F6` |
| RB | Square | Green `#22C55E` |
| WR | Triangle | Yellow `#EAB308` |
| TE | Diamond | Red `#EF4444` |
| OL | Square (large) | Gray `#9CA3AF` |
| DL | Square (large) | Dark `#374151` |
| LB | Square | Purple `#A855F7` |
| CB | Circle | Red `#EF4444` |
| S | Circle | Orange `#F97316` |

### TypeScript Interfaces (canonical — frontend owns these)

```typescript
// ─── Primitives ──────────────────────────────────────────────

interface Vector2D {
  x: number;  // 0–1200 logical units
  y: number;  // 0–533 logical units
}

type PlayerRole     = 'QB' | 'RB' | 'WR' | 'TE' | 'OL' | 'DL' | 'LB' | 'CB' | 'S';
type Side           = 'offense' | 'defense';
type Difficulty     = 'beginner' | 'intermediate' | 'advanced';
type TacticalLayer  = 1 | 2 | 3 | 4;

type ConceptCategory =
  | 'formation-offense'
  | 'formation-defense'
  | 'coverage'
  | 'blitz'
  | 'route-concept'
  | 'pocket-mechanics'
  | 'ball-physics'
  | 'geometry';

// ─── Paths ───────────────────────────────────────────────────

interface PathStyle {
  color:       string;   // hex
  width:       number;
  dashArray?:  number[]; // e.g. [8,4] for dashed
  arrowHead?:  boolean;
  opacity:     number;   // 0–1
}

// Four path types cover all football motion patterns:
interface StraightPath  { type: 'straight';  from: Vector2D; to: Vector2D; style: PathStyle; }
interface QuadraticPath { type: 'quadratic'; from: Vector2D; control: Vector2D; to: Vector2D; style: PathStyle; }
interface CubicPath     { type: 'cubic';     from: Vector2D; control1: Vector2D; control2: Vector2D; to: Vector2D; style: PathStyle; }
interface ArcPath       { type: 'arc';       from: Vector2D; apex: Vector2D; to: Vector2D; style: PathStyle; }

type MotionPath = StraightPath | QuadraticPath | CubicPath | ArcPath;

// ─── Ball ────────────────────────────────────────────────────

type BallTrajectoryType = 'line-drive' | 'rainbow' | 'screen' | 'handoff' | 'scramble';

interface BallState {
  position: Vector2D;
  trajectory?: {
    type:       BallTrajectoryType;
    path:       ArcPath | StraightPath;
    airtimeMs:  number;
    peakHeight: number;  // visual arc height in logical units
  };
}

// ─── Overlays ────────────────────────────────────────────────

interface ZoneOverlay {
  type: 'zone'; id: string; label: string;
  points: Vector2D[]; fill: string; opacity: number;
}
interface GeometryOverlay {
  type: 'geometry'; id: string; label: string;
  lines: Array<{ from: Vector2D; to: Vector2D; style: PathStyle }>;
}
interface HighlightOverlay {
  type: 'highlight'; id: string; playerIds: string[]; color: string; pulse: boolean;
}

type Overlay = ZoneOverlay | GeometryOverlay | HighlightOverlay;

// ─── Annotations ─────────────────────────────────────────────

type AnnotationStyle = 'label' | 'callout' | 'arrow-label' | 'bracket';

interface Annotation {
  id: string; position: Vector2D; text: string;
  style: AnnotationStyle; color?: string;
}

// ─── Phase (Animation Frame) ─────────────────────────────────

interface PlayerState {
  playerId:     string;
  position:     Vector2D;
  paths?:       MotionPath[];
  highlighted?: boolean;
  opacity?:     number;
}

interface Phase {
  id:           number;   // 0-indexed
  label:        string;   // "Pre-snap", "Route development", etc.
  description:  string;   // shown in right panel during this phase
  durationMs:   number;
  players:      PlayerState[];
  ball?:        BallState;
  overlays?:    Overlay[];
  annotations?: Annotation[];
}

// ─── Concept (Core Unit) ─────────────────────────────────────

interface Concept {
  id:               string;  // uuid
  slug:             string;  // e.g. "cover-2-defense"
  label:            string;  // e.g. "Cover 2"
  category:         ConceptCategory;
  subcategory?:     string;
  tags:             string[];
  difficulty:       Difficulty;
  layers:           TacticalLayer[];
  description:      string;  // one-line summary
  explanation:      string;  // full markdown for right panel
  roster:           Player[];
  phases:           Phase[];
  counters?:        string[];  // concept slugs that defeat this
  relatedConcepts?: string[];
  aiContext:        string;    // plain text injected into RAG
  isUserCreated:    boolean;
  createdAt:        string;
  updatedAt:        string;
}
```

### Database Schema (MariaDB)

The backend stores concepts as structured JSON inside relational rows. The `roster`, `phases`, `counters`, `related`, `tags`, and `layers` columns are all `JSON` type. This avoids premature normalization while keeping query performance acceptable at concept-library scale.

```sql
CREATE TABLE concepts (
  id          CHAR(36)     PRIMARY KEY,
  slug        VARCHAR(120) UNIQUE NOT NULL,
  label       VARCHAR(120) NOT NULL,
  category    VARCHAR(60)  NOT NULL,
  subcategory VARCHAR(60),
  tags        JSON         NOT NULL DEFAULT '[]',
  difficulty  ENUM('beginner','intermediate','advanced') NOT NULL,
  layers      JSON         NOT NULL DEFAULT '[]',
  description TEXT         NOT NULL,
  explanation LONGTEXT     NOT NULL,
  roster      JSON         NOT NULL,
  phases      JSON         NOT NULL,
  counters    JSON         NOT NULL DEFAULT '[]',
  related     JSON         NOT NULL DEFAULT '[]',
  ai_context  TEXT         NOT NULL,
  created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE users (
  id           CHAR(36)     PRIMARY KEY,
  email        VARCHAR(255) UNIQUE NOT NULL,
  display_name VARCHAR(120),
  password     VARCHAR(255) NOT NULL,
  role         ENUM('guest','user','admin') DEFAULT 'user',
  created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE user_bookmarks (
  id         CHAR(36)  PRIMARY KEY,
  user_id    CHAR(36)  NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  concept_id CHAR(36)  NOT NULL REFERENCES concepts(id) ON DELETE CASCADE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_bookmark (user_id, concept_id)
);

CREATE TABLE user_progress (
  id           CHAR(36)  PRIMARY KEY,
  user_id      CHAR(36)  NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  concept_id   CHAR(36)  NOT NULL REFERENCES concepts(id) ON DELETE CASCADE,
  completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_progress (user_id, concept_id)
);

CREATE TABLE custom_plays (
  id         CHAR(36)     PRIMARY KEY,
  user_id    CHAR(36)     NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  label      VARCHAR(120) NOT NULL,
  category   VARCHAR(60),
  tags       JSON         NOT NULL DEFAULT '[]',
  roster     JSON         NOT NULL,
  phases     JSON         NOT NULL,
  is_public  BOOLEAN      DEFAULT FALSE,
  thumbnail  VARCHAR(512),
  created_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE ai_sessions (
  id          CHAR(36)  PRIMARY KEY,
  user_id     CHAR(36)  REFERENCES users(id) ON DELETE SET NULL,
  session_key CHAR(64)  NOT NULL UNIQUE,
  messages    JSON      NOT NULL DEFAULT '[]',
  concept_ids JSON      NOT NULL DEFAULT '[]',
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

---

## API Contracts

All responses are JSON. Authentication uses Laravel Sanctum cookies for SPA sessions.

```
# Concept library
GET  /api/concepts                   Summary list (no phases payload)
GET  /api/concepts/{slug}            Full concept with phases, overlays, paths
GET  /api/concepts?category={cat}    Filter by category
GET  /api/concepts?tags={tag,tag}    Filter by tags
GET  /api/concepts?q={search}        Keyword search on label + description

# User bookmarks
GET  /api/user/bookmarks             List bookmarks
POST /api/user/bookmarks             Add  { concept_id }
DEL  /api/user/bookmarks/{id}        Remove

# Progress
GET  /api/user/progress              List completed concept slugs
POST /api/user/progress              Mark complete  { concept_id }

# AI assistant
POST /api/ai/query                   Query  { query, concept_slugs[] }
GET  /api/ai/session/{key}           Resume session (guest continuity)

# Guest migration
POST /api/user/migrate-guest         { bookmarks[], completed[], session_key }
```

---

## Application Modes

### Lesson Mode
Single concept. Full right-panel explanation. Phased animation. AI assistant available in sidebar. Navigation links to counters and related concepts.

### Compare Mode
Two concept slots side by side. Sync toggle (default: on). Shared or independent playback strip. AI can compare the two loaded concepts on demand.

**Sync behavior:**

When `synced = true`, any play/pause/step dispatched to either slot mirrors to the other. If Slot A has more phases than Slot B, Slot B freezes on its final phase. Speed is locked on both. This is the correct default — comparative understanding requires simultaneous animation.

When `synced = false`, each slot has independent controls in its panel header.

```
┌─────────────────────────────────────────────────────────┐
│  [Slot A label]          🔗 SYNC ON        [Slot B label]│
├────────────────────────┬────────────────────────────────┤
│       CANVAS A         │       CANVAS B                 │
├────────────────────────┴────────────────────────────────┤
│  ◀◀  ◀  ▶  ▶▶   ──────●────────   0.5x  1x  2x        │
└─────────────────────────────────────────────────────────┘
```

### Geometry Lab
Static or slow-animated spatial mechanics. Pursuit angle triangles, catch-point geometry, leverage diagrams. Slider controls for angle and distance variables. No full play animation.

### Custom Lab *(Phase 2)*
Drag-and-drop player placement. Path drawing tools. Save to authenticated account. Optional public sharing to community library.

---

## AI Assistant

### Architecture

The AI assistant is a **bounded tactical advisor**. It reasons exclusively over structured concept data retrieved from MariaDB. It never generates football plays from scratch.

```
User query
    │
    ▼
Laravel AiController
    │
    ├── 1. Parse intent (explain / compare / counter / pre-snap-read / recommend)
    │
    ├── 2. Retrieve relevant concepts from MariaDB
    │       (by category, tags, slug, keyword match on label + description)
    │
    ├── 3. Assemble context block from concept.ai_context fields
    │       (hard limit: 4,000 tokens of concept data per request)
    │
    ├── 4. Call Anthropic API (claude-sonnet-4-20250514)
    │       System prompt + context block + user query
    │
    └── 5. Stream response back to client via SSE
```

### System Prompt

```
You are a football tactics instructor embedded in the Football Field Intelligence System.

You have access to a structured library of football concepts. Each concept includes:
- a label and category
- a plain-text tactical explanation
- information about counters and related concepts

RULES:
1. Only explain tactics using the concepts provided in the CONTEXT block below.
2. Never invent formations, coverages, or route names not present in the context.
3. If the user asks about something not in the context, say so and suggest which category might help.
4. Use plain, direct language. Avoid jargon unless the user demonstrates familiarity.
5. When comparing two concepts: Offense advantage / Defense advantage / Key read.
6. Never describe play outcomes or game results. Describe spatial and timing mechanics only.
7. Maximum response length: 600 tokens.

CONTEXT:
{injected concept ai_context fields}
```

### Intent Classification

Before calling the Anthropic API, the Laravel controller classifies query intent. This controls response format and enables guardrails.

| Intent | Trigger phrases | Response format |
|---|---|---|
| Explain | "what is", "explain", "how does X work" | Paragraph + key reads |
| Compare | "X vs Y", "what's the difference" | Offense / Defense / Key read |
| Counter | "how do you beat X", "what stops X" | Concept name + mechanical reason |
| Pre-snap read | "what should the QB see", "what does X tell you" | Ordered visual cue list |
| Recommend | "what should I study next" | Slug list with one-line reasons |

If intent classification fails, default to Explain. If context retrieval returns zero concepts, decline to answer and surface the concept search instead.

### Rate Limiting (Redis)

- Authenticated users: 20 queries per hour
- Guest users: 5 queries per session
- Context cap: 4,000 tokens of concept data per request
- Response cap: 600 tokens

---

## User State & Persistence

### Guest → Authenticated model

The full simulator is available without an account. Authentication unlocks persistence and export — not functionality.

| Capability | Guest | Authenticated |
|---|---|---|
| Browse library | ✅ | ✅ |
| Animate concepts | ✅ | ✅ |
| Bookmark concepts | ✅ localStorage (max 20) | ✅ server (unlimited) |
| Track progress | ✅ localStorage | ✅ server |
| Compare mode | ✅ | ✅ |
| AI assistant | ✅ 5 queries/session | ✅ 20 queries/hour |
| Save custom plays | ❌ | ✅ Phase 2 |
| Export diagrams | ❌ | ✅ PNG via MinIO |
| Cross-device sync | ❌ | ✅ |

### Guest localStorage key

```typescript
const STORAGE_KEY = 'ffis_guest_state';

interface GuestLocalState {
  bookmarks:   string[];   // concept slugs, max 20
  completed:   string[];   // concept slugs
  aiSession:   string;     // session key for AI continuity
  preferences: {
    animationSpeed:  0.5 | 1 | 2;
    defaultSynced:   boolean;
    showAnnotations: boolean;
    showOverlays:    boolean;
  };
}
```

### Migration on sign-up

When a guest creates an account, their localStorage state is posted to `POST /api/user/migrate-guest`. The server merges bookmarks and progress. The localStorage entry is cleared. No study history is lost.

---

## Tactical Layers

Concepts belong to one or more layers of complexity. The library presents them in order.

| Layer | Focus |
|---|---|
| 1 — Fundamentals | Formations, fronts, position roles, one-high vs two-high |
| 2 — Tactical Interaction | Blitz vs screen, Cover 2 vs Smash, Trips vs Cover 3, run fits |
| 3 — Spatial Geometry | Pursuit angles, catch-point triangle, leverage, rotation |
| 4 — Ball Physics | Line-drive, rainbow deep ball, underthrown geometry, trajectories |

---

## Project Principles

**Clarity over complexity.** Every visualization must aid understanding. If a visual element cannot be explained in one sentence, remove it.

**Schema-first.** The concept data model is the source of truth. The UI renders it. The AI reasons over it. Neither invents.

**Bounded AI.** The assistant explains what exists in the library. It does not generate football plays or invent tactics.

**Sync as default.** Compare mode starts synced. Understanding tactical difference requires seeing simultaneous reaction to the same situation.

**Graceful guest experience.** A user who never creates an account can complete the full learning curriculum. Auth unlocks persistence, not capability.

**Retro elegance.** Dark backgrounds, vivid tokens, disciplined palette, crisp grid. The aesthetic must evoke a coach's workstation — not a consumer sports app.

**Consistency is non-negotiable.** Token shapes, colors, and coordinate conventions must never change between concepts. A safety is always an orange circle. A WR is always a yellow triangle. Inconsistency destroys the visual language the user is learning.

---

## What This System Is Not

- It is not a play-diagramming tool for coaches (no freehand drawing in Phase 1)
- It is not a statistics or analytics platform
- It is not a fantasy sports tool
- It is not a game or simulation of live play
- The AI assistant is not a general football chatbot — it is bounded to the concept library

---

*FFIS Architecture v2.0 — see FFIS_architecture.md for full data model, database schema, compare mode synchronization design, and API contracts.*
